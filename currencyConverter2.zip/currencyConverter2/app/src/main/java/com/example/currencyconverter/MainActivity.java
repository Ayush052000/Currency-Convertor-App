package com.example.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void convertAmount(View view)
    {
        EditText getAmount = (EditText) findViewById(R.id.number);
        Double amount = 73.18 * Double.parseDouble(getAmount.getText().toString());
        Toast.makeText(MainActivity.this, String.format("%.2f",amount) + "/-" , Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}